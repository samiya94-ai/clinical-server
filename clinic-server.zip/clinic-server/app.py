"""Doctor House clinic server.

Staff sign in to manage patients and history files. Doctors and admins can
create secure share links that open WITHOUT any clinic or Claude login.
Links expire, can be capped by number of opens, can require a passcode sent
separately, can be cancelled, and every access is logged.
"""
import hashlib
import hmac
import os
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from functools import wraps
from getpass import getpass

from flask import (Flask, abort, current_app, flash, g, make_response, redirect, render_template,
                   request, send_file, session, url_for)
from flask_sqlalchemy import SQLAlchemy
from jinja2 import DictLoader
from sqlalchemy import func, or_
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from templates import TEMPLATES

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MAX_FILE = 15 * 1024 * 1024
IDLE_SECONDS = 30 * 60
LOCK_AFTER = 5           # failed sign-ins before a short lock
MAX_PIN_TRIES = 5        # wrong passcodes before a share link is cancelled
ROLES = ("admin", "doctor", "receptionist")
CLINICAL = ("admin", "doctor")  # may see history files and share them

# extension -> (mime type, magic bytes that the file must start with)
ALLOWED = {
    "pdf": ("application/pdf", [b"%PDF"]),
    "jpg": ("image/jpeg", [b"\xff\xd8\xff"]),
    "jpeg": ("image/jpeg", [b"\xff\xd8\xff"]),
    "png": ("image/png", [b"\x89PNG"]),
    "webp": ("image/webp", [b"RIFF"]),
    "doc": ("application/msword", [b"\xd0\xcf\x11\xe0"]),
    "xls": ("application/vnd.ms-excel", [b"\xd0\xcf\x11\xe0"]),
    "docx": ("application/vnd.openxmlformats-officedocument.wordprocessingml.document", [b"PK\x03\x04"]),
    "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", [b"PK\x03\x04"]),
    "txt": ("text/plain; charset=utf-8", None),
}
INLINE_OK = {"application/pdf", "image/jpeg", "image/png", "image/webp", "text/plain; charset=utf-8"}

db = SQLAlchemy()


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def sha256_text(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def clean(value, limit):
    return (value or "").strip()[:limit]


# ---------------------------------------------------------------- models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    pw_hash = db.Column(db.String(255), nullable=False)
    active = db.Column(db.Boolean, default=True, nullable=False)
    must_change = db.Column(db.Boolean, default=False, nullable=False)
    failed_logins = db.Column(db.Integer, default=0, nullable=False)
    locked_until = db.Column(db.DateTime, nullable=True)


class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), default="", index=True)
    age = db.Column(db.String(10), default="")
    gender = db.Column(db.String(10), default="")
    address = db.Column(db.String(255), default="")
    emergency = db.Column(db.String(150), default="")
    allergies = db.Column(db.String(255), default="")
    diagnosis = db.Column(db.Text, default="")
    status = db.Column(db.String(20), default="active")
    created_at = db.Column(db.DateTime, default=utcnow)


class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False, index=True)
    original_name = db.Column(db.String(255), nullable=False)
    mime = db.Column(db.String(100), nullable=False)
    size = db.Column(db.Integer, nullable=False)
    storage_name = db.Column(db.String(64), unique=True, nullable=False)
    sha256 = db.Column(db.String(64), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("user.id"))
    uploaded_at = db.Column(db.DateTime, default=utcnow)
    patient = db.relationship("Patient")


class Share(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token_hash = db.Column(db.String(64), unique=True, nullable=False)
    document_id = db.Column(db.Integer, db.ForeignKey("document.id"), nullable=False)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"))
    created_at = db.Column(db.DateTime, default=utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    max_views = db.Column(db.Integer, nullable=False)
    views = db.Column(db.Integer, default=0, nullable=False)
    passcode_hash = db.Column(db.String(255), nullable=True)
    attempts = db.Column(db.Integer, default=0, nullable=False)
    revoked_at = db.Column(db.DateTime, nullable=True)
    note = db.Column(db.String(120), default="")
    document = db.relationship("Document")


class ShareAccess(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    share_id = db.Column(db.Integer, db.ForeignKey("share.id"), nullable=False, index=True)
    at = db.Column(db.DateTime, default=utcnow)
    ip = db.Column(db.String(45), default="")
    user_agent = db.Column(db.String(255), default="")
    event = db.Column(db.String(30), nullable=False)


class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    at = db.Column(db.DateTime, default=utcnow)
    user_id = db.Column(db.Integer, nullable=True)
    action = db.Column(db.String(40), nullable=False)
    detail = db.Column(db.String(300), default="")


def audit(user_id, action, detail=""):
    db.session.add(AuditLog(at=utcnow(), user_id=user_id, action=action, detail=detail[:300]))
    db.session.commit()


# ---------------------------------------------------------------- helpers
def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


def share_status(s):
    if s.revoked_at:
        return "cancelled"
    if s.expires_at < utcnow():
        return "expired"
    if s.views >= s.max_views:
        return "used up"
    return "active"


def find_share(token):
    if not token or len(token) > 100:
        return None
    return Share.query.filter_by(token_hash=sha256_text(token)).first()


def log_access(s, event):
    db.session.add(ShareAccess(share_id=s.id, at=utcnow(),
                               ip=(request.remote_addr or "")[:45],
                               user_agent=(request.user_agent.string or "")[:255], event=event))


def gone():
    return render_template("share_gone.html"), 410


def no_store(body):
    resp = make_response(body)
    resp.headers["Cache-Control"] = "no-store, private"
    return resp


def send_stored(doc, inline):
    path = os.path.join(current_app.config["UPLOAD_DIR"], doc.storage_name)
    if not os.path.isfile(path):
        abort(404)
    resp = send_file(path, mimetype=doc.mime, as_attachment=not inline, download_name=doc.original_name)
    return no_store(resp)


def share_file_allowed(s):
    """Recipients may fetch the file while the link is valid. The view that
    used the last allowed open is still allowed to load its own preview."""
    if s.revoked_at or s.expires_at < utcnow():
        return False
    if s.passcode_hash and not session.get(f"unlocked_{s.id}"):
        return False
    return s.views < s.max_views or bool(session.get(f"open_{s.id}"))


def login_required(roles=None):
    def deco(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("login"))
            if roles and g.user.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapper
    return deco


# ---------------------------------------------------------------- app
def create_app(overrides=None):
    app = Flask(__name__)
    base_url = os.environ.get("PUBLIC_BASE_URL", "http://localhost:5000").rstrip("/")
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///" + os.path.join(BASE_DIR, "clinic.db")),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        MAX_CONTENT_LENGTH=MAX_FILE + 512 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=base_url.startswith("https://"),
        PUBLIC_BASE_URL=base_url,
        UPLOAD_DIR=os.environ.get("UPLOAD_DIR", os.path.join(BASE_DIR, "uploads")),
    )
    if overrides:
        app.config.update(overrides)
    app.jinja_loader = DictLoader(TEMPLATES)
    app.jinja_env.globals.update(csrf_token=csrf_token, share_status=share_status)
    db.init_app(app)

    with app.app_context():
        db.create_all()

    @app.before_request
    def guard():
        g.user = None
        if request.method == "POST":
            expected = session.get("csrf", "")
            given = request.form.get("csrf", "")
            if not expected or not hmac.compare_digest(expected, given):
                abort(400)
        uid = session.get("uid")
        if not uid:
            return None
        if utcnow().timestamp() - session.get("last", 0) > IDLE_SECONDS:
            session.clear()
            flash("You were signed out after 30 minutes of inactivity.")
            return redirect(url_for("login"))
        user = db.session.get(User, uid)
        if not user or not user.active:
            session.clear()
            return redirect(url_for("login"))
        g.user = user
        session["last"] = utcnow().timestamp()
        if user.must_change and request.endpoint not in ("change_password", "logout"):
            return redirect(url_for("change_password"))
        return None

    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        frame = "'self'" if request.endpoint in ("share_file", "doc_file") else "'none'"
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; frame-src 'self'; style-src 'self' 'unsafe-inline'; "
            "script-src 'none'; object-src 'none'; base-uri 'none'; form-action 'self'; "
            f"frame-ancestors {frame}")
        if request.path.startswith(("/s/", "/documents/")):
            resp.headers["Cache-Control"] = "no-store, private"
        return resp

    # ----- staff accounts ---------------------------------------------
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            uname = clean(request.form.get("username"), 40).lower()
            pw = request.form.get("password", "")
            user = User.query.filter_by(username=uname).first()
            now = utcnow()
            if user and user.locked_until and user.locked_until > now:
                audit(user.id, "login_locked", uname)
                return render_template("login.html", error="Too many attempts. Try again in 15 minutes.")
            if user and user.active and check_password_hash(user.pw_hash, pw):
                user.failed_logins = 0
                user.locked_until = None
                session.clear()
                session["uid"] = user.id
                session["last"] = now.timestamp()
                csrf_token()
                db.session.commit()
                audit(user.id, "login", "")
                return redirect(url_for("change_password") if user.must_change else url_for("patients"))
            if user:
                user.failed_logins += 1
                if user.failed_logins >= LOCK_AFTER:
                    user.locked_until = now + timedelta(minutes=15)
                    user.failed_logins = 0
                db.session.commit()
            audit(user.id if user else None, "login_failed", uname)
            return render_template("login.html", error="Incorrect username or password.")
        return render_template("login.html", error=None)

    @app.post("/logout")
    def logout():
        if g.user:
            audit(g.user.id, "logout", "")
        session.clear()
        return redirect(url_for("login"))

    @app.route("/account/password", methods=["GET", "POST"])
    @login_required()
    def change_password():
        if request.method == "POST":
            old = request.form.get("old", "")
            new = request.form.get("new", "")
            new2 = request.form.get("new2", "")
            if not check_password_hash(g.user.pw_hash, old):
                flash("Your current password is wrong.")
            elif len(new) < 10:
                flash("The new password must be at least 10 characters.")
            elif new != new2:
                flash("The two new passwords do not match.")
            else:
                g.user.pw_hash = generate_password_hash(new)
                g.user.must_change = False
                db.session.commit()
                audit(g.user.id, "password_changed", "")
                flash("Password updated.")
                return redirect(url_for("patients"))
        return render_template("change_password.html")

    @app.get("/users")
    @login_required(("admin",))
    def users():
        return render_template("users.html", users=User.query.order_by(User.name).all())

    @app.post("/users")
    @login_required(("admin",))
    def user_create():
        username = clean(request.form.get("username"), 40).lower()
        name = clean(request.form.get("name"), 120)
        role = request.form.get("role", "")
        pw = request.form.get("password", "")
        if not re.fullmatch(r"[a-z0-9._-]{3,20}", username) or not name or role not in ROLES:
            flash("Enter a name, a username (3–20 letters, digits or . _ -) and a role.")
        elif len(pw) < 10:
            flash("Temporary password must be at least 10 characters.")
        elif User.query.filter_by(username=username).first():
            flash("That username already exists.")
        else:
            db.session.add(User(username=username, name=name, role=role,
                                pw_hash=generate_password_hash(pw), must_change=True))
            db.session.commit()
            audit(g.user.id, "user_created", f"{username} ({role})")
            flash("Account created. The person must change the temporary password at first sign-in.")
        return redirect(url_for("users"))

    @app.post("/users/<int:uid>/toggle")
    @login_required(("admin",))
    def user_toggle(uid):
        user = db.get_or_404(User, uid)
        if user.username == "admin" or user.id == g.user.id:
            flash("This account cannot be disabled.")
        else:
            user.active = not user.active
            db.session.commit()
            audit(g.user.id, "user_enabled" if user.active else "user_disabled", user.username)
        return redirect(url_for("users"))

    # ----- patients ----------------------------------------------------
    @app.get("/patients")
    @login_required()
    def patients():
        q = clean(request.args.get("q"), 80)
        query = Patient.query
        if q:
            like = f"%{q}%"
            query = query.filter(or_(Patient.name.ilike(like), Patient.phone.ilike(like), Patient.code.ilike(like)))
        return render_template("patients.html", patients=query.order_by(Patient.name).limit(200).all(), q=q)

    @app.post("/patients")
    @login_required()
    def patient_create():
        name = clean(request.form.get("name"), 120)
        phone = clean(request.form.get("phone"), 20)
        if not name:
            flash("Enter the patient's name.")
            return redirect(url_for("patients"))
        if phone and Patient.query.filter_by(phone=phone).first():
            flash("Another patient already uses this phone number.")
            return redirect(url_for("patients"))
        last = db.session.query(func.max(Patient.id)).scalar() or 0
        p = Patient(code=f"DH-{last + 1:04d}", name=name, phone=phone,
                    age=clean(request.form.get("age"), 10), gender=clean(request.form.get("gender"), 10),
                    address=clean(request.form.get("address"), 255), emergency=clean(request.form.get("emergency"), 150),
                    allergies=clean(request.form.get("allergies"), 255), diagnosis=clean(request.form.get("diagnosis"), 4000),
                    status="active", created_at=utcnow())
        db.session.add(p)
        db.session.commit()
        audit(g.user.id, "patient_created", p.code)
        return redirect(url_for("patient_view", pid=p.id))

    @app.get("/patients/<int:pid>")
    @login_required()
    def patient_view(pid):
        p = db.get_or_404(Patient, pid)
        can = g.user.role in CLINICAL
        docs, shares = [], []
        if can:
            docs = Document.query.filter_by(patient_id=p.id).order_by(Document.uploaded_at.desc()).all()
            shares = Share.query.filter_by(patient_id=p.id).order_by(Share.created_at.desc()).limit(50).all()
        return render_template("patient.html", p=p, docs=docs, shares=shares, can_clinical=can)

    @app.post("/patients/<int:pid>/upload")
    @login_required(CLINICAL)
    def upload(pid):
        p = db.get_or_404(Patient, pid)
        back = redirect(url_for("patient_view", pid=p.id))
        f = request.files.get("file")
        if not f or not f.filename:
            flash("Choose a file to upload.")
            return back
        ext = os.path.splitext(f.filename)[1].lower().lstrip(".")
        if ext not in ALLOWED:
            flash("This file type is not allowed.")
            return back
        data = f.read(MAX_FILE + 1)
        if len(data) > MAX_FILE:
            flash("The file is larger than 15 MB.")
            return back
        mime, signatures = ALLOWED[ext]
        if signatures and not any(data.startswith(sig) for sig in signatures):
            flash("The file content does not match its type.")
            return back
        if ext == "txt":
            try:
                data.decode("utf-8")
            except UnicodeDecodeError:
                flash("Text files must be UTF-8.")
                return back
        storage = uuid.uuid4().hex
        os.makedirs(current_app.config["UPLOAD_DIR"], exist_ok=True)
        with open(os.path.join(current_app.config["UPLOAD_DIR"], storage), "wb") as out:
            out.write(data)
        doc = Document(patient_id=p.id, original_name=secure_filename(f.filename) or f"file.{ext}",
                       mime=mime, size=len(data), storage_name=storage,
                       sha256=hashlib.sha256(data).hexdigest(), uploaded_by=g.user.id, uploaded_at=utcnow())
        db.session.add(doc)
        db.session.commit()
        audit(g.user.id, "file_uploaded", f"{p.code}: {doc.original_name}")
        flash("File uploaded.")
        return back

    @app.get("/documents/<int:did>")
    @login_required(CLINICAL)
    def doc_file(did):
        d = db.get_or_404(Document, did)
        audit(g.user.id, "file_opened", f"{d.patient.code}: {d.original_name}")
        return send_stored(d, inline=d.mime in INLINE_OK)

    # ----- secure share links -----------------------------------------
    @app.post("/documents/<int:did>/share")
    @login_required(CLINICAL)
    def share_create(did):
        d = db.get_or_404(Document, did)
        try:
            hours = min(168, max(1, int(request.form.get("hours", 24))))
        except ValueError:
            hours = 24
        try:
            max_views = min(10, max(1, int(request.form.get("max_views", 3))))
        except ValueError:
            max_views = 3
        use_pin = request.form.get("pin") == "on"
        now = utcnow()
        token = secrets.token_urlsafe(32)
        pin = f"{secrets.randbelow(10 ** 6):06d}" if use_pin else None
        s = Share(token_hash=sha256_text(token), document_id=d.id, patient_id=d.patient_id,
                  created_by=g.user.id, created_at=now, expires_at=now + timedelta(hours=hours),
                  max_views=max_views, views=0, attempts=0,
                  passcode_hash=generate_password_hash(pin) if pin else None,
                  note=clean(request.form.get("note"), 120))
        db.session.add(s)
        db.session.commit()
        audit(g.user.id, "share_created", f"share {s.id} for {d.original_name}")
        link = f"{current_app.config['PUBLIC_BASE_URL']}/s/{token}"
        expires = s.expires_at.strftime("%d %b %Y %H:%M") + " UTC"
        msg_link = (f"Dear {d.patient.name}, your report from Doctor House Physiotherapy is ready: {link}\n"
                    f"The link expires on {expires}.")
        msg_pin = f"Passcode for your Doctor House report: {pin}" if pin else ""
        return render_template("share_created.html", link=link, pin=pin, expires=expires,
                               max_views=max_views, wa_link=msg_link, wa_pin=msg_pin,
                               subject="Your report from Doctor House",
                               mail_body=msg_link + ("\nThe passcode will be sent separately." if pin else ""),
                               pid=d.patient_id)

    @app.post("/shares/<int:sid>/revoke")
    @login_required(CLINICAL)
    def share_revoke(sid):
        s = db.get_or_404(Share, sid)
        if not s.revoked_at:
            s.revoked_at = utcnow()
            log_access(s, "cancelled")
            db.session.commit()
            audit(g.user.id, "share_cancelled", f"share {s.id}")
        flash("Link cancelled.")
        return redirect(url_for("patient_view", pid=s.patient_id))

    @app.get("/s/<token>")
    def share_open(token):
        s = find_share(token)
        if not s or share_status(s) != "active":
            return gone()
        if s.passcode_hash and not session.get(f"unlocked_{s.id}"):
            return no_store(render_template("share_gate.html", token=token, error=None))
        s.views += 1
        session[f"open_{s.id}"] = True
        log_access(s, "open")
        db.session.commit()
        doc = s.document
        return no_store(render_template(
            "share_view.html", token=token, doc=doc, patient=doc.patient, note=s.note,
            expires=s.expires_at.strftime("%d %b %Y %H:%M") + " UTC",
            left=max(0, s.max_views - s.views), inline=doc.mime in INLINE_OK,
            is_image=doc.mime.startswith("image/")))

    @app.post("/s/<token>/unlock")
    def share_unlock(token):
        s = find_share(token)
        if not s or share_status(s) != "active" or not s.passcode_hash:
            return gone()
        pin = clean(request.form.get("pin"), 6)
        if check_password_hash(s.passcode_hash, pin):
            session[f"unlocked_{s.id}"] = True
            log_access(s, "unlock")
            db.session.commit()
            return redirect(url_for("share_open", token=token))
        s.attempts += 1
        log_access(s, "wrong_passcode")
        error = "Incorrect passcode."
        if s.attempts >= MAX_PIN_TRIES:
            s.revoked_at = utcnow()
            log_access(s, "locked_after_attempts")
            error = "Too many wrong attempts. This link has been cancelled. Ask the clinic for a new one."
        db.session.commit()
        return no_store(render_template("share_gate.html", token=token, error=error))

    @app.get("/s/<token>/file")
    def share_file(token):
        s = find_share(token)
        if not s or not share_file_allowed(s):
            return gone()
        doc = s.document
        inline = request.args.get("inline") == "1" and doc.mime in INLINE_OK
        log_access(s, "preview" if inline else "download")
        db.session.commit()
        return send_stored(doc, inline=inline)

    @app.errorhandler(400)
    def bad_request(_e):
        return render_template("error.html", message="The form expired. Please go back and try again."), 400

    @app.cli.command("create-admin")
    def create_admin():
        """Create the first administrator account."""
        username = input("Admin username: ").strip().lower()
        name = input("Full name: ").strip()
        pw = getpass("Password (min 10 characters): ")
        if len(pw) < 10 or not name or User.query.filter_by(username=username).first():
            print("Not created: check the username, name and password length.")
            return
        db.session.add(User(username=username, name=name, role="admin", pw_hash=generate_password_hash(pw)))
        db.session.commit()
        print("Admin account created.")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=False)
