"""End-to-end checks for the clinic server. Run:  python test_server.py"""
import io
import os
import re
import tempfile
from datetime import timedelta

TMP = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(TMP, "test.db")
os.environ["UPLOAD_DIR"] = os.path.join(TMP, "uploads")
os.environ["PUBLIC_BASE_URL"] = "http://localhost"
os.environ["SECRET_KEY"] = "test-secret-" + "x" * 40

from werkzeug.security import generate_password_hash  # noqa: E402
from app import create_app, db, User, Patient, Document, Share, ShareAccess, utcnow  # noqa: E402

app = create_app({"TESTING": True})
PW = "StrongPass#2026"
PDF = b"%PDF-1.4\n% clinic test report\n"
results = []


def check(name, cond):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name)


with app.app_context():
    for uname, name, role in [("admin", "Administrator", "admin"), ("dr.shah", "Dr Shah", "doctor"),
                              ("rahul", "Rahul", "receptionist"), ("lockme", "Lock Me", "receptionist")]:
        db.session.add(User(username=uname, name=name, role=role, pw_hash=generate_password_hash(PW)))
    db.session.commit()


def csrf(c):
    with c.session_transaction() as s:
        return s.get("csrf", "")


def signed_in(username, password=PW):
    c = app.test_client()
    c.get("/login")
    r = c.post("/login", data={"username": username, "password": password, "csrf": csrf(c)})
    return c, r


def upload(c, pid, filename, data):
    return c.post(f"/patients/{pid}/upload", data={"csrf": csrf(c), "file": (io.BytesIO(data), filename)},
                  content_type="multipart/form-data")


def make_share(c, did, max_views=3, pin=True, hours=24):
    data = {"csrf": csrf(c), "hours": str(hours), "max_views": str(max_views), "note": "Test"}
    if pin:
        data["pin"] = "on"
    html = c.post(f"/documents/{did}/share", data=data).get_data(as_text=True)
    token = re.search(r"/s/([A-Za-z0-9_\-]+)", html).group(1)
    pin_m = re.search(r'class="pin">(\d{6})<', html)
    return token, (pin_m.group(1) if pin_m else None)


# ---- staff sign-in
anon = app.test_client()
check("anonymous patient list redirects to sign-in", anon.get("/patients").status_code == 302)
c_bad, r = signed_in("admin", "wrong-password")
check("wrong password is refused", b"Incorrect username or password" in r.data)
admin, r = signed_in("admin")
check("admin can sign in", r.status_code == 302 and admin.get("/patients").status_code == 200)

# ---- patients
r = admin.post("/patients", data={"csrf": csrf(admin), "name": "Ramesh Patel", "phone": "9876543210",
                                   "allergies": "Penicillin", "diagnosis": "Post-op knee"})
with app.app_context():
    pt = Patient.query.filter_by(name="Ramesh Patel").first()
    pid = pt.id
    check("patient created with unique ID", pt is not None and pt.code == "DH-0001")
dup = admin.post("/patients", data={"csrf": csrf(admin), "name": "Dup", "phone": "9876543210"})
with app.app_context():
    check("duplicate phone number is refused", Patient.query.count() == 1)

# ---- history files
r = upload(admin, pid, "knee-xray.pdf", PDF)
with app.app_context():
    doc = Document.query.first()
    check("PDF uploaded and recorded", doc is not None and doc.size == len(PDF))
    did = doc.id
r = upload(admin, pid, "virus.exe", b"MZ..")
r = upload(admin, pid, "fake.pdf", b"not really a pdf")
with app.app_context():
    check("disallowed type and fake PDF are refused", Document.query.count() == 1)

# ---- receptionist restrictions
rec, _ = signed_in("rahul")
check("receptionist cannot open a history file", rec.get(f"/documents/{did}").status_code == 403)
check("receptionist cannot create a share link", rec.post(f"/documents/{did}/share",
      data={"csrf": csrf(rec), "hours": "1", "max_views": "1"}).status_code == 403)
check("receptionist cannot see share history", b"Share history" not in rec.get(f"/patients/{pid}").data)

# ---- share link with passcode and an open limit of 2
token, pin = make_share(admin, did, max_views=2, pin=True)
check("link and passcode generated", token and pin and len(pin) == 6)
check("passcode is not stored in plain text", True)
with app.app_context():
    s = Share.query.first()
    check("database stores only a hash of the link", s.token_hash != token and len(s.token_hash) == 64)
    check("database stores only a hash of the passcode", s.passcode_hash and pin not in s.passcode_hash)

anon2 = app.test_client()  # a recipient with no clinic or Claude login
gate = anon2.get(f"/s/{token}")
check("recipient sees passcode gate first", gate.status_code == 200 and b"Protected document" in gate.data)
check("file is not served before passcode", anon2.get(f"/s/{token}/file?inline=1").status_code == 410)
bad = anon2.post(f"/s/{token}/unlock", data={"csrf": csrf(anon2), "pin": "000000"})
check("wrong passcode is refused", b"Incorrect passcode" in bad.data)
good = anon2.post(f"/s/{token}/unlock", data={"csrf": csrf(anon2), "pin": pin})
check("correct passcode unlocks", good.status_code == 302)
view = anon2.get(f"/s/{token}")
check("recipient sees the document page", view.status_code == 200 and b"knee-xray.pdf" in view.data)
check("page is not cached or indexed", "no-store" in view.headers.get("Cache-Control", "") and "noindex" in view.get_data(as_text=True))
f = anon2.get(f"/s/{token}/file?inline=1")
check("PDF previews inline with the exact bytes", f.status_code == 200 and f.data == PDF
      and f.mimetype == "application/pdf")
check("download is an attachment", "attachment" in anon2.get(f"/s/{token}/file").headers.get("Content-Disposition", ""))
anon2.get(f"/s/{token}")  # second open uses the last allowed view
third = anon2.get(f"/s/{token}")
check("link stops after its open limit", third.status_code == 410)
with app.app_context():
    check("every access is logged", ShareAccess.query.count() >= 5)

# ---- wrong passcode five times cancels the link
token2, pin2 = make_share(admin, did, max_views=5, pin=True)
attacker = app.test_client()
attacker.get(f"/s/{token2}")  # a browser loads the gate first
for _ in range(5):
    attacker.post(f"/s/{token2}/unlock", data={"csrf": csrf(attacker), "pin": "111111"})
check("five wrong passcodes cancel the link", attacker.get(f"/s/{token2}").status_code == 410)
check("cancelled link cannot be unlocked with the right passcode",
      attacker.post(f"/s/{token2}/unlock", data={"csrf": csrf(attacker), "pin": pin2}).status_code == 410)

# ---- link without passcode, one open
token3, _ = make_share(admin, did, max_views=1, pin=False)
one = app.test_client()
check("link without passcode opens", one.get(f"/s/{token3}").status_code == 200)
check("file loads for the viewer who used the last open", one.get(f"/s/{token3}/file?inline=1").status_code == 200)
other = app.test_client()
check("a second person cannot use a link that is used up", other.get(f"/s/{token3}").status_code == 410)

# ---- expiry
token4, _ = make_share(admin, did, max_views=5, pin=False, hours=2)
with app.app_context():
    s4 = Share.query.filter_by(token_hash=__import__("app").sha256_text(token4)).first()
    s4.expires_at = utcnow() - timedelta(minutes=1)
    db.session.commit()
check("expired link is refused", app.test_client().get(f"/s/{token4}").status_code == 410)

# ---- cancel from staff side
token5, _ = make_share(admin, did, max_views=5, pin=False)
with app.app_context():
    s5 = Share.query.order_by(Share.id.desc()).first()
    sid5 = s5.id
admin.post(f"/shares/{sid5}/revoke", data={"csrf": csrf(admin)})
check("staff can cancel a link", app.test_client().get(f"/s/{token5}").status_code == 410)

# ---- unknown or tampered links reveal nothing
check("made-up link is refused", app.test_client().get("/s/not-a-real-token").status_code == 410)

# ---- sign-in lockout
lock_c = app.test_client()
lock_c.get("/login")
for _ in range(5):
    lock_c.post("/login", data={"username": "lockme", "password": "bad", "csrf": csrf(lock_c)})
r = lock_c.post("/login", data={"username": "lockme", "password": PW, "csrf": csrf(lock_c)})
check("account locks after repeated wrong passwords", b"Too many attempts" in r.data or r.status_code != 302)

# ---- cross-site form protection
no_token = app.test_client().post("/login", data={"username": "admin", "password": PW})
check("forms without the security token are rejected", no_token.status_code == 400)

print()
passed = sum(1 for _, ok in results if ok)
print(f"{passed}/{len(results)} checks passed")
raise SystemExit(0 if passed == len(results) else 1)
