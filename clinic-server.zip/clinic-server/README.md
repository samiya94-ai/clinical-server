# Doctor House clinic server

Secure staff accounts, patient history files, and share links that open in any browser
without a clinic or Claude login.

## What it does
- **Staff sign-in** for admins, doctors and receptionists. Passwords are stored as salted hashes.
  Five wrong passwords lock the account for 15 minutes. Sessions end after 30 minutes idle.
- **Roles:** receptionists manage patients only. Doctors and admins also upload and share history files.
  Only admins manage staff accounts.
- **History files:** PDF, Word, Excel, text and images, up to 15 MB. The content is checked against the file
  type, and files are stored under random names outside the public web folder.
- **Share links** (doctors and admins):
  - The link carries a 256-bit random token. The server stores only a hash of it.
  - Valid for 1 to 168 hours.
  - Opens limited to 1 to 10.
  - Optional 6-digit passcode, shown once, to be sent in a separate message.
  - Five wrong passcodes cancel the link.
  - Staff can cancel any link at any time.
  - Every open, download and failed attempt is logged.
  - Pages are not cached, not indexed, and do not leak the link in the Referer header.
- **Audit log:** sign-ins, uploads, file views, share creation and cancellation are recorded.

## Set up on your computer (test first)
```bash
cd clinic-server
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export SECRET_KEY="$(python -c 'import secrets;print(secrets.token_hex(32))')"
export PUBLIC_BASE_URL="http://localhost:5000"
flask --app app create-admin          # creates the first administrator
flask --app app run --port 5000       # open http://localhost:5000
python test_server.py                 # runs the 34 security and workflow checks
```

## Put it online (needed before real patient data)
1. **Database:** create a MySQL database (or use the MySQL service from your host). Set
   `DATABASE_URL=mysql+pymysql://USER:PASSWORD@HOST/DBNAME?charset=utf8mb4`.
2. **Environment variables** on the host:
   - `SECRET_KEY` (a long random value, kept secret)
   - `PUBLIC_BASE_URL=https://your-domain` (must be https, so links and cookies are secure)
   - `DATABASE_URL`
   - `UPLOAD_DIR` (a folder outside the public web root, with backups)
3. **Start command:** `gunicorn -w 2 -b 0.0.0.0:$PORT app:app`
4. **HTTPS:** most hosts provide it automatically. Do not serve the site over plain http.
5. **Create the admin** once on the server: `flask --app app create-admin`.
6. **Backups:** back up the database and the uploads folder every day.

## Sharing a report with a patient or another doctor
1. Open the patient, upload the file, and click **Create secure link**.
2. Choose how long the link lasts and how many times it can be opened. Keep the passcode option on.
3. Click **WhatsApp: send link**, then **WhatsApp: send passcode** (or use email). Send them as two separate messages.
4. The recipient opens the link in any browser, enters the passcode, and views or downloads the file.

## Limits to know about
- Anyone who has the link and passcode can open it until it expires or runs out of opens. Do not forward links.
- Links are sent by staff from their own WhatsApp or email. The server does not send messages itself.
- The server does not yet replace the on-device app data. Connecting the Doctor House app to this server is the next step.
- Before real use, add a regular backup, a monitored domain with HTTPS, and a review of your local data-protection duties.
