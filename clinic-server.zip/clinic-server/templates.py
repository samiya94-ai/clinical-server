"""Page templates (kept in code so the server is a small, self-contained project)."""

CSS = """
:root{--p:#0B6E63;--pd:#0E3B37;--pl:#EAF4F3;--bg:#F4F6F8;--line:#E3E8EA;--muted:#67777B;--text:#1B2A2C;--bad:#B42318;--ok:#067647}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
header{background:var(--pd);color:#fff;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
header b{font-size:15px}
header nav{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
header a{color:#fff;text-decoration:none;font-weight:600;font-size:13px;padding:6px 10px;border-radius:8px}
header a:hover{background:rgba(255,255,255,.12)}
main{max-width:1040px;margin:22px auto;padding:0 16px}
.card{background:#fff;border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:16px}
h1{font-size:20px;margin:0 0 10px}
h2{font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin:0 0 10px}
label{display:block;font-size:12px;font-weight:600;color:var(--muted);margin:10px 0 4px;text-transform:uppercase;letter-spacing:.4px}
input,select,textarea{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:9px;font:inherit;background:#fff;color:var(--text)}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--p);box-shadow:0 0 0 3px rgba(11,110,99,.15)}
button,.btn{background:var(--p);color:#fff;border:0;border-radius:9px;padding:9px 14px;font:inherit;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block}
button:hover,.btn:hover{background:var(--pd)}
button.ghost,.btn.ghost{background:#fff;color:var(--text);border:1px solid var(--line)}
button.ghost:hover,.btn.ghost:hover{background:var(--pl)}
button.danger{background:#FEF3F2;color:var(--bad);border:1px solid #FECDCA}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:700px){.grid2{grid-template-columns:1fr}}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:9px 6px;border-bottom:1px solid var(--line);font-size:13.5px;vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.4px}
.badge{display:inline-block;font-size:11.5px;font-weight:600;padding:2px 8px;border-radius:6px;background:var(--pl);color:var(--pd)}
.bad{color:var(--bad)}
.muted{color:var(--muted)}
.alert{background:#FEF3F2;color:var(--bad);border:1px solid #FECDCA;border-radius:9px;padding:10px 12px;margin-bottom:12px}
.notice{background:var(--pl);color:var(--pd);border-radius:9px;padding:10px 12px;margin:10px 0}
.link{word-break:break-all;font-family:ui-monospace,Menlo,Consolas,monospace;background:var(--bg);padding:10px;border-radius:8px;border:1px solid var(--line);font-size:13px}
.pin{font-size:30px;letter-spacing:8px;font-weight:700;color:var(--pd);margin:6px 0}
iframe,img.preview{width:100%;height:70vh;border:1px solid var(--line);border-radius:10px;background:#fff;object-fit:contain}
.center{max-width:380px;margin:50px auto}
details summary{cursor:pointer;color:var(--p);font-weight:600;margin:4px 0}
.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
"""

BASE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>{{ title or 'Doctor House' }}</title>
<style>""" + CSS + """</style></head>
<body>
{% if g.user %}
<header>
  <b>Doctor House · Clinic records</b>
  <nav>
    <a href="{{ url_for('patients') }}">Patients</a>
    {% if g.user.role == 'admin' %}<a href="{{ url_for('users') }}">Staff</a>{% endif %}
    <a href="{{ url_for('change_password') }}">Password</a>
    <form method="post" action="{{ url_for('logout') }}" style="margin:0">
      <input type="hidden" name="csrf" value="{{ csrf_token() }}">
      <button class="ghost">Sign out</button>
    </form>
  </nav>
</header>
{% endif %}
<main>
{% with msgs = get_flashed_messages() %}{% for m in msgs %}<div class="alert">{{ m }}</div>{% endfor %}{% endwith %}
{% block body %}{% endblock %}
</main>
</body></html>
"""

LOGIN = """{% extends "base.html" %}{% block body %}
<div class="center card">
  <h1>Staff sign-in</h1>
  <p class="muted">Doctor House clinic records</p>
  <form method="post">
    <input type="hidden" name="csrf" value="{{ csrf_token() }}">
    <label>Username</label><input name="username" autocomplete="username" required autofocus>
    <label>Password</label><input type="password" name="password" autocomplete="current-password" required>
    {% if error %}<div class="alert" style="margin-top:12px">{{ error }}</div>{% endif %}
    <button style="width:100%;margin-top:16px">Sign in</button>
  </form>
  <p class="muted" style="font-size:12px;margin-top:14px">Accounts are created by the clinic administrator.</p>
</div>
{% endblock %}"""

PATIENTS = """{% extends "base.html" %}{% block body %}
<div class="card">
  <form method="get" class="actions">
    <input name="q" value="{{ q }}" placeholder="Search by name, phone or ID" style="flex:1;min-width:220px">
    <button class="ghost">Search</button>
  </form>
</div>
<div class="card">
  <h2>Patients ({{ patients|length }})</h2>
  <table>
    <tr><th>ID</th><th>Name</th><th>Phone</th><th>Status</th></tr>
    {% for p in patients %}
    <tr><td>{{ p.code }}</td><td><a href="{{ url_for('patient_view', pid=p.id) }}">{{ p.name }}</a></td><td>{{ p.phone or '—' }}</td><td><span class="badge">{{ p.status }}</span></td></tr>
    {% else %}<tr><td colspan="4" class="muted">No patients found.</td></tr>{% endfor %}
  </table>
</div>
<div class="card">
  <h2>New patient</h2>
  <form method="post" action="{{ url_for('patient_create') }}">
    <input type="hidden" name="csrf" value="{{ csrf_token() }}">
    <div class="grid2">
      <div><label>Full name</label><input name="name" required></div>
      <div><label>Phone</label><input name="phone" inputmode="tel"></div>
      <div><label>Age</label><input name="age"></div>
      <div><label>Gender</label><select name="gender"><option value=""></option><option>Female</option><option>Male</option><option>Other</option></select></div>
      <div><label>Emergency contact</label><input name="emergency"></div>
      <div><label>Allergies</label><input name="allergies"></div>
    </div>
    <label>Address</label><input name="address">
    <label>Diagnosis and medical history</label><textarea name="diagnosis" rows="3"></textarea>
    <button style="margin-top:14px">Save patient</button>
  </form>
</div>
{% endblock %}"""

PATIENT = """{% extends "base.html" %}{% block body %}
<div class="card">
  <h1>{{ p.name }} <span class="muted" style="font-size:13px;font-weight:500">{{ p.code }}</span></h1>
  <div class="grid2">
    <div>Phone: {{ p.phone or '—' }}</div>
    <div>Age / gender: {{ p.age or '—' }} {{ p.gender }}</div>
    <div>Emergency contact: {{ p.emergency or '—' }}</div>
    <div>Allergies: <span class="{{ 'bad' if p.allergies }}">{{ p.allergies or 'None recorded' }}</span></div>
  </div>
  <p><b>Diagnosis and history:</b> {{ p.diagnosis or 'Not recorded' }}</p>
</div>
{% if can_clinical %}
<div class="card">
  <h2>Patient history files</h2>
  <form method="post" action="{{ url_for('upload', pid=p.id) }}" enctype="multipart/form-data" class="actions">
    <input type="hidden" name="csrf" value="{{ csrf_token() }}">
    <input type="file" name="file" required accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png,.webp" style="flex:1;min-width:220px">
    <button>Upload</button>
  </form>
  <p class="muted" style="font-size:12px">PDF, Word, Excel, text or image. Up to 15 MB.</p>
  <table>
    <tr><th>File</th><th>Uploaded</th><th>Size</th><th>Share</th></tr>
    {% for d in docs %}
    <tr>
      <td><a href="{{ url_for('doc_file', did=d.id) }}" target="_blank" rel="noopener">{{ d.original_name }}</a></td>
      <td>{{ d.uploaded_at.strftime('%d %b %Y') }}</td>
      <td>{{ (d.size / 1024) | round | int }} KB</td>
      <td>
        <details><summary>Create secure link</summary>
          <form method="post" action="{{ url_for('share_create', did=d.id) }}">
            <input type="hidden" name="csrf" value="{{ csrf_token() }}">
            <div class="grid2">
              <div><label>Valid for (hours, max 168)</label><input name="hours" type="number" value="24" min="1" max="168"></div>
              <div><label>Maximum opens (1–10)</label><input name="max_views" type="number" value="3" min="1" max="10"></div>
            </div>
            <label>Note for your records (optional)</label><input name="note" maxlength="120">
            <label style="text-transform:none;font-weight:500;color:var(--text);margin-top:12px"><input type="checkbox" name="pin" checked style="width:auto;margin-right:8px">Require a passcode (sent separately)</label>
            <button style="margin-top:10px">Create link</button>
          </form>
        </details>
      </td>
    </tr>
    {% else %}<tr><td colspan="4" class="muted">No files uploaded yet.</td></tr>{% endfor %}
  </table>
</div>
<div class="card">
  <h2>Share history</h2>
  <table>
    <tr><th>File</th><th>Created</th><th>Expires (UTC)</th><th>Opens</th><th>Status</th><th></th></tr>
    {% for s in shares %}
    <tr>
      <td>{{ s.document.original_name }}{% if s.note %}<br><span class="muted">{{ s.note }}</span>{% endif %}</td>
      <td>{{ s.created_at.strftime('%d %b %H:%M') }}</td>
      <td>{{ s.expires_at.strftime('%d %b %H:%M') }}</td>
      <td>{{ s.views }} / {{ s.max_views }}</td>
      <td>{{ share_status(s) }}</td>
      <td>{% if share_status(s) == 'active' %}
        <form method="post" action="{{ url_for('share_revoke', sid=s.id) }}"><input type="hidden" name="csrf" value="{{ csrf_token() }}"><button class="danger">Cancel link</button></form>
      {% endif %}</td>
    </tr>
    {% else %}<tr><td colspan="6" class="muted">No links created yet.</td></tr>{% endfor %}
  </table>
</div>
{% endif %}
{% endblock %}"""

SHARE_CREATED = """{% extends "base.html" %}{% block body %}
<div class="card">
  <h1>Secure link created</h1>
  <p>Send the link to the recipient. It opens in any browser with no clinic or Claude login. It stops working after the limits below.</p>
  <h2>Link</h2>
  <div class="link">{{ link }}</div>
  <p class="muted">Valid until {{ expires }} · up to {{ max_views }} opens{% if pin %} · passcode required{% endif %}</p>
  {% if pin %}
  <h2 style="margin-top:16px">Passcode (shown only once)</h2>
  <div class="pin">{{ pin }}</div>
  <p class="muted">Send the passcode in a separate message from the link.</p>
  {% endif %}
  <h2 style="margin-top:18px">Send</h2>
  <div class="actions">
    <a class="btn" target="_blank" rel="noopener" href="https://wa.me/?text={{ wa_link | urlencode }}">WhatsApp: send link</a>
    {% if pin %}<a class="btn ghost" target="_blank" rel="noopener" href="https://wa.me/?text={{ wa_pin | urlencode }}">WhatsApp: send passcode</a>{% endif %}
    <a class="btn ghost" href="mailto:?subject={{ subject | urlencode }}&amp;body={{ mail_body | urlencode }}">Email</a>
  </div>
  <p style="margin-top:18px"><a href="{{ url_for('patient_view', pid=pid) }}">Back to patient</a></p>
</div>
{% endblock %}"""

SHARE_GATE = """{% extends "base.html" %}{% block body %}
<div class="center card">
  <h1>Protected document</h1>
  <p class="muted">Enter the 6-digit passcode you received from the clinic.</p>
  <form method="post" action="{{ url_for('share_unlock', token=token) }}">
    <input type="hidden" name="csrf" value="{{ csrf_token() }}">
    <label>Passcode</label>
    <input name="pin" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required autofocus>
    {% if error %}<div class="alert" style="margin-top:12px">{{ error }}</div>{% endif %}
    <button style="width:100%;margin-top:14px">Open document</button>
  </form>
</div>
{% endblock %}"""

SHARE_VIEW = """{% extends "base.html" %}{% block body %}
<div class="card">
  <h1>{{ doc.original_name }}</h1>
  <p class="muted">Patient: {{ patient.name }} · Doctor House Physiotherapy · Available until {{ expires }} · Opens left after this: {{ left }}</p>
  {% if note %}<p><b>Note:</b> {{ note }}</p>{% endif %}
  {% if inline %}
    {% if is_image %}
    <img class="preview" src="{{ url_for('share_file', token=token, inline=1) }}" alt="{{ doc.original_name }}">
    {% else %}
    <iframe src="{{ url_for('share_file', token=token, inline=1) }}" title="{{ doc.original_name }}"></iframe>
    {% endif %}
  {% else %}
    <div class="notice">This file will download to your device.</div>
  {% endif %}
  <p style="margin-top:14px"><a class="btn" href="{{ url_for('share_file', token=token) }}">Download</a></p>
  <p class="muted" style="font-size:12px">This link is personal. Please do not forward it, and do not open it on a shared computer.</p>
</div>
{% endblock %}"""

SHARE_GONE = """{% extends "base.html" %}{% block body %}
<div class="center card">
  <h1>This link is no longer available</h1>
  <p class="muted">It may have expired, reached its limit or been cancelled. Please contact Doctor House Physiotherapy for a new link.</p>
</div>
{% endblock %}"""

ERROR = """{% extends "base.html" %}{% block body %}
<div class="center card"><h1>Something went wrong</h1><p class="muted">{{ message }}</p></div>
{% endblock %}"""

USERS = """{% extends "base.html" %}{% block body %}
<div class="card">
  <h2>Staff accounts</h2>
  <table>
    <tr><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th></th></tr>
    {% for u in users %}
    <tr><td>{{ u.name }}</td><td>{{ u.username }}</td><td>{{ u.role }}</td><td>{{ 'active' if u.active else 'disabled' }}</td>
      <td>{% if u.username != 'admin' %}
        <form method="post" action="{{ url_for('user_toggle', uid=u.id) }}"><input type="hidden" name="csrf" value="{{ csrf_token() }}"><button class="ghost">{{ 'Disable' if u.active else 'Enable' }}</button></form>
      {% endif %}</td></tr>
    {% endfor %}
  </table>
</div>
<div class="card">
  <h2>Add staff</h2>
  <form method="post" action="{{ url_for('user_create') }}">
    <input type="hidden" name="csrf" value="{{ csrf_token() }}">
    <div class="grid2">
      <div><label>Full name</label><input name="name" required></div>
      <div><label>Username</label><input name="username" required pattern="[a-z0-9._-]{3,20}"></div>
      <div><label>Role</label><select name="role"><option value="doctor">Doctor</option><option value="receptionist">Receptionist</option><option value="admin">Admin</option></select></div>
      <div><label>Temporary password (min 10)</label><input name="password" type="password" minlength="10" required></div>
    </div>
    <button style="margin-top:14px">Create account</button>
  </form>
</div>
{% endblock %}"""

CHANGE_PASSWORD = """{% extends "base.html" %}{% block body %}
<div class="center card">
  <h1>Change password</h1>
  <form method="post">
    <input type="hidden" name="csrf" value="{{ csrf_token() }}">
    <label>Current password</label><input type="password" name="old" required>
    <label>New password (min 10 characters)</label><input type="password" name="new" minlength="10" required>
    <label>Confirm new password</label><input type="password" name="new2" minlength="10" required>
    <button style="width:100%;margin-top:14px">Update password</button>
  </form>
</div>
{% endblock %}"""

TEMPLATES = {
    "base.html": BASE,
    "login.html": LOGIN,
    "patients.html": PATIENTS,
    "patient.html": PATIENT,
    "share_created.html": SHARE_CREATED,
    "share_gate.html": SHARE_GATE,
    "share_view.html": SHARE_VIEW,
    "share_gone.html": SHARE_GONE,
    "error.html": ERROR,
    "users.html": USERS,
    "change_password.html": CHANGE_PASSWORD,
}
